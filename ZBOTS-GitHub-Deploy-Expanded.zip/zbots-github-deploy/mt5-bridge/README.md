# ZBOTS MT5 Bridge (Windows VPS)

## Prerequisites
- Windows VPS with MetaTrader 5 desktop terminal installed.
- Python 3.10+ (64-bit).
- MT5 terminal installed and permitted to connect to the target broker server.
- Network access from Supabase Edge Functions to this bridge endpoint (HTTPS strongly recommended).

## Install
```powershell
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
$env:MT5_BRIDGE_SECRET="USE_THE_SAME_LONG_RANDOM_SECRET_AS_SUPABASE"
$env:MT5_ALLOWED_USER_ID="THE_AUTH_USER_UUID_ALLOWED_TO_USE_THIS_SINGLE_TERMINAL"
uvicorn main:app --host 0.0.0.0 --port 8787
```

Use a Windows service manager (for example NSSM) to keep the bridge running in production.
Put the bridge behind HTTPS reverse proxy/firewall. Restrict inbound traffic where possible.

## Important
This first bridge release supports MT5 login, account info and open positions. It intentionally returns HTTP 501 for bot-control because no validated strategy executor has been supplied. Do not expose the bridge directly to browsers. Call it only through the authenticated Supabase `bridge-proxy` Edge Function. The bridge secret must be long, random, private and rotated if exposed. This starter is restricted to one explicitly allowlisted Supabase user (`MT5_ALLOWED_USER_ID`) because one MT5 terminal session must never be shared across unrelated users. For a multi-user commercial deployment, provision isolated terminal sessions/worker processes per user/account and enforce account ownership in the orchestration layer.

The MT5 Python package requires the MetaTrader 5 terminal and Windows environment. This is not a Linux/serverless process.
