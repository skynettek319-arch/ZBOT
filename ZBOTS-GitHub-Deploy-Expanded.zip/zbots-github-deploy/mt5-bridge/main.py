"""
ZBOTS MT5 bridge — Windows VPS service.
Requires: Windows, MetaTrader 5 desktop terminal installed and logged in/accessible,
Python 3.10+, MetaTrader5, FastAPI, uvicorn.
IMPORTANT: This bridge is a guarded integration foundation. It connects and reads
the MT5 terminal. Bot strategy execution is deliberately not implemented as a fake.
"""
import os
from typing import Any
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
import MetaTrader5 as mt5

SECRET = os.environ.get("MT5_BRIDGE_SECRET", "")
ALLOWED_USER_ID = os.environ.get("MT5_ALLOWED_USER_ID", "")
app = FastAPI(title="ZBOTS MT5 Bridge", version="1.0.0")

def guard(x_zbots_bridge_secret: str | None, x_zbots_user_id: str | None):
    if not SECRET or x_zbots_bridge_secret != SECRET:
        raise HTTPException(status_code=401, detail="Invalid bridge authorization.")
    if not ALLOWED_USER_ID or x_zbots_user_id != ALLOWED_USER_ID:
        raise HTTPException(status_code=403, detail="This bridge is not assigned to this ZBOTS user.")

def ensure_terminal():
    if not mt5.initialize():
        raise HTTPException(status_code=503, detail=f"MT5 initialize failed: {mt5.last_error()}")

def serialize(obj: Any):
    if hasattr(obj, "_asdict"):
        return {k: serialize(v) for k, v in obj._asdict().items()}
    if isinstance(obj, tuple):
        return [serialize(v) for v in obj]
    if isinstance(obj, list):
        return [serialize(v) for v in obj]
    return obj

class Payload(BaseModel):
    broker: str | None = None
    server: str | None = None
    account: int | None = None
    password: str | None = None
    account_type: str | None = None
    command: str | None = None
    strategy: str | None = None
    risk_percent: float | None = None
    max_daily_loss_percent: float | None = None
    max_positions: int | None = None

@app.get("/health")
def health():
    return {"status": "ok", "mt5_initialized": bool(mt5.terminal_info())}

@app.post("/api/connect")
def connect(p: Payload, x_zbots_bridge_secret: str | None = Header(default=None), x_zbots_user_id: str | None = Header(default=None)):
    guard(x_zbots_bridge_secret, x_zbots_user_id)
    if not p.account or not p.password or not p.server:
        raise HTTPException(status_code=400, detail="MT5 account, password and server are required.")
    if not mt5.initialize():
        raise HTTPException(status_code=503, detail=f"MT5 initialize failed: {mt5.last_error()}")
    ok = mt5.login(login=p.account, password=p.password, server=p.server)
    if not ok:
        err = mt5.last_error()
        raise HTTPException(status_code=401, detail=f"MT5 login failed: {err}")
    info = mt5.account_info()
    if info is None:
        raise HTTPException(status_code=503, detail="MT5 account information unavailable.")
    result = serialize(info)
    # Do not persist or log the supplied trading password.
    return {"connected": True, "account": result}

@app.post("/api/account")
def account(x_zbots_bridge_secret: str | None = Header(default=None), x_zbots_user_id: str | None = Header(default=None)):
    guard(x_zbots_bridge_secret, x_zbots_user_id); ensure_terminal()
    info = mt5.account_info()
    if info is None: raise HTTPException(status_code=503, detail="No MT5 account is logged in.")
    return {"account": serialize(info)}

@app.post("/api/positions")
def positions(x_zbots_bridge_secret: str | None = Header(default=None), x_zbots_user_id: str | None = Header(default=None)):
    guard(x_zbots_bridge_secret, x_zbots_user_id); ensure_terminal()
    rows = mt5.positions_get()
    if rows is None: raise HTTPException(status_code=503, detail=f"positions_get failed: {mt5.last_error()}")
    return {"positions": serialize(rows)}

@app.post("/api/bot-control")
def bot_control(p: Payload, x_zbots_bridge_secret: str | None = Header(default=None), x_zbots_user_id: str | None = Header(default=None)):
    guard(x_zbots_bridge_secret, x_zbots_user_id)
    if p.command not in {"start", "pause", "stop"}:
        raise HTTPException(status_code=400, detail="Unsupported bot command.")
    # Safe by design: never claim a bot is running until a tested strategy engine exists.
    raise HTTPException(status_code=501, detail="Strategy execution engine is not installed. Account read/connection is available; automated order execution remains disabled.")

@app.post("/api/history")
def history(x_zbots_bridge_secret: str | None = Header(default=None), x_zbots_user_id: str | None = Header(default=None)):
    guard(x_zbots_bridge_secret, x_zbots_user_id); ensure_terminal()
    from datetime import datetime, timedelta
    deals = mt5.history_deals_get(datetime.now() - timedelta(days=90), datetime.now())
    if deals is None: raise HTTPException(status_code=503, detail=f"history_deals_get failed: {mt5.last_error()}")
    return {"deals": serialize(deals)}

@app.on_event("shutdown")
def shutdown():
    mt5.shutdown()
