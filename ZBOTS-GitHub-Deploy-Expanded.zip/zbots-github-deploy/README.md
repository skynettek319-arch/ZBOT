# ZBOTS — Smarter Trading. Automated.

ZBOTS is a responsive MT5 trading workspace built with React + Vite, Supabase Auth/Postgres/Edge Functions, an xAI Grok assistant, and a separately hosted Windows MT5 bridge. The supplied ZBOTS logo artwork is retained as `public/zbots-logo.png` and is used by the splash and brand UI.

## Included in this expanded package

- Responsive dark-navy/electric-blue trader workspace and animated launch screen.
- Supabase email/password authentication and optional Google OAuth.
- Broker selector and MT5 connection interface.
- Dashboard, live-position view, trading-history/analytics placeholders, notifications and profile settings.
- ZChatbot through a Supabase Edge Function; xAI credentials remain server-side.
- Strategy Studio: create and save independently versionable strategy module drafts with format metadata and rule specifications.
- Strategy library records in Supabase, plus lifecycle states and schema for validation/backtest/demo/live run records.
- Admin-only console: platform overview, user listing, suspend/restore actions, plan pricing/availability editor and platform configuration.
- Protected admin Edge Function using Supabase Auth + service-role operations; the service-role key is never shipped to the browser.
- Additional Supabase migration for profiles/roles, strategy modules/versions/runs, plans, subscriptions, global settings and admin audit events.
- GitHub Actions workflow for GitHub Pages deployment.

## Honest implementation status

This is an expanded application foundation, not a claim that every external service has been provisioned or every trading capability is production-ready.

- Strategy Studio saves user-owned strategy descriptions/manifests as drafts. It does **not** compile or execute arbitrary Python, MQL5 or Pine Script code. Each executable format needs a dedicated, sandboxed adapter and validation pipeline.
- Strategy validation, historical backtesting, demo forward-testing and live strategy execution require implementation of the corresponding worker/MT5 executor. The strategy-run database is provided as a foundation; it does not fabricate successful test results.
- The MT5 bridge is a single-terminal connection foundation. Do not expose it as a multi-tenant production service without per-user isolated terminal sessions, encrypted credential handling, strict authorization, execution reconciliation and monitoring.
- The current bot-control route intentionally does not claim that orders are being executed. Build and test a deterministic strategy executor before enabling it.
- The admin console can list users and suspend/restore accounts after the admin Edge Function is deployed. It displays up to the first 100 accounts; implement pagination for larger deployments.
- Pricing is stored in Supabase and can be edited by an administrator. Checkout, recurring billing, invoices, refunds and payment webhook verification are **not** enabled. Integrate a payment provider before collecting money or granting paid entitlements.
- Global settings currently save configuration values. Maintenance-mode enforcement and live-trading feature gates must be enforced server-side before being treated as operational controls.
- Account and trade data are only real when returned by a configured MT5 bridge. No sample trade is represented as a real position.

## 1. Deploy the frontend

1. Create a GitHub repository and upload the project.
2. In GitHub repository settings, enable Pages with **GitHub Actions** as the source.
3. Add repository Actions secrets:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. Push to `main`. The workflow runs `npm install`, `npm run build` and publishes `dist`.
5. Set the deployed URL and allowed redirect URLs in Supabase Authentication settings.

For local development:

```bash
npm install
cp .env.example .env
# Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY
npm run dev
```

## 2. Configure Supabase database

Run these migrations in order in the Supabase SQL Editor, or apply them with the Supabase CLI:

1. `supabase/migrations/202611060001_initial_schema.sql`
2. `supabase/migrations/202611060002_admin_strategy_commerce.sql`

### Grant the first administrator

1. Register your own ZBOTS account through the app.
2. In the Supabase SQL Editor, replace the email below with the exact email used for that account and run it once:

```sql
update public.profiles p
set role = 'admin'
from auth.users u
where p.id = u.id
  and lower(u.email) = lower('YOUR_ADMIN_EMAIL');
```

3. Sign out and sign back in. The Admin navigation item should appear.
4. Keep administrator accounts protected with strong passwords and MFA. Do not allow users to choose their own role during registration.

The profile trigger creates new profiles with the `trader` role. A database trigger prevents ordinary users from changing their own role or account status.

## 3. Deploy Supabase Edge Functions

Deploy:

```bash
supabase functions deploy grok-chat
supabase functions deploy bridge-proxy
supabase functions deploy admin-control
```

Configure function secrets in Supabase (never add these as `VITE_` frontend variables):

```bash
supabase secrets set XAI_API_KEY=YOUR_XAI_KEY
supabase secrets set XAI_MODEL=grok-3-mini
supabase secrets set MT5_BRIDGE_URL=https://YOUR-BRIDGE-HOST
supabase secrets set MT5_BRIDGE_SECRET=YOUR_LONG_RANDOM_SECRET
```

The `admin-control` function uses Supabase's server-side `SUPABASE_SERVICE_ROLE_KEY` environment variable. Never expose that key in GitHub Pages, frontend code, public repository files or browser storage. Keep Edge Function JWT verification enabled.

## 4. Grok assistant

Create an xAI API key and configure `XAI_API_KEY` as a Supabase Edge Function secret. ZChatbot invokes the `grok-chat` function. The browser must never receive the xAI API key. Set the desired model using `XAI_MODEL`.

## 5. MT5 bridge

See `mt5-bridge/README.md`. The bridge must run on a Windows VPS with MetaTrader 5 installed. Configure `MT5_BRIDGE_URL` and `MT5_BRIDGE_SECRET` in Supabase secrets. The browser communicates through the authenticated Supabase proxy.

Before enabling automated or live execution, implement and independently test:

- A deterministic strategy interface and per-format adapters.
- Isolated execution environments for uploaded/custom strategy code.
- Per-user/per-account MT5 terminal sessions and authorization.
- Broker-aware position sizing, contract specifications and margin checks.
- Daily loss, drawdown, exposure and maximum-position limits enforced inside the executor.
- Duplicate-order/idempotency protection and order/position reconciliation.
- Stop-loss/take-profit validation, broker rejection handling and safe recovery.
- Demo forward testing, audit logs, monitoring and emergency stop.
- Explicit live-trading consent and a server-side live-account feature gate.

## 6. Admin and commercial operations

- The Admin console appears only when `profiles.role = 'admin'` and the profile is active.
- User suspension/restoration is performed server-side through `admin-control` and Supabase Auth Admin API.
- Plan display pricing and activation can be edited in Admin after the second migration is applied.
- Subscription records and payment-provider fields are prepared in the database. Payment checkout and entitlement enforcement still require a payment integration with verified server-side webhooks.
- Admin changes and overview access are recorded in `admin_audit`.

## 7. Security checklist

- Never commit `.env`, API keys, service-role keys, MT5 passwords or bridge secrets.
- Use HTTPS for every production endpoint.
- Restrict bridge network access; rotate secrets if exposed.
- Review RLS policies and Edge Function authorization before launch.
- Do not store raw MT5 trading passwords in the browser or database.
- Use per-user isolated MT5 sessions before offering multi-user automated trading.
- Add MFA for administrators.
- Do not enable live execution until the executor, strategy adapters and risk controls have passed independent demo testing.

## Build verification

GitHub Actions runs `npm install` and `npm run build` on pushes and pull requests to `main`.
