import { createClient } from '@supabase/supabase-js'

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined
export const hasSupabase = Boolean(url && key && !url.includes('YOUR_PROJECT') && !key.includes('YOUR_'))
export const supabase = hasSupabase ? createClient(url!, key!) : null

export async function bridgeRequest(action: string, payload: Record<string, unknown> = {}) {
  if (!supabase) throw new Error('Configure Supabase before connecting a trading account.')
  const { data: { session } } = await supabase.auth.getSession()
  if (!session) throw new Error('Please sign in first.')
  const { data, error } = await supabase.functions.invoke(import.meta.env.VITE_BRIDGE_FUNCTION_NAME || 'bridge-proxy', {
    body: { action, ...payload }
  })
  if (error) throw new Error(error.message)
  if (data?.error) throw new Error(data.error)
  return data
}

export async function askGrok(message: string, history: {role: string; content: string}[] = []) {
  if (!supabase) throw new Error('Configure Supabase before using ZChatbot.')
  const { data, error } = await supabase.functions.invoke(import.meta.env.VITE_GROK_FUNCTION_NAME || 'grok-chat', {
    body: { message, history }
  })
  if (error) throw new Error(error.message)
  return data?.reply || 'The assistant returned an empty response.'
}