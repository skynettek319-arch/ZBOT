const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405, headers: cors });
  const bridgeUrl = Deno.env.get("MT5_BRIDGE_URL");
  const bridgeSecret = Deno.env.get("MT5_BRIDGE_SECRET");
  if (!bridgeUrl || !bridgeSecret) return Response.json({ error: "MT5 bridge is not configured on the server." }, { status: 503, headers: cors });
  try {
    const auth = req.headers.get("Authorization") || "";
    if (!auth.startsWith("Bearer ")) return Response.json({ error: "Unauthorized" }, { status: 401, headers: cors });
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const { createClient } = await import("https://esm.sh/@supabase/supabase-js@2");
    const supabase = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: auth } } });
    const { data: { user }, error } = await supabase.auth.getUser();
    if (error || !user) return Response.json({ error: "Unauthorized" }, { status: 401, headers: cors });
    const payload = await req.json();
    const response = await fetch(`${bridgeUrl.replace(/\/$/, "")}/api/${encodeURIComponent(String(payload.action || ""))}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-ZBOTS-Bridge-Secret": bridgeSecret, "X-ZBOTS-User-Id": user.id },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(20000),
    });
    const data = await response.json().catch(() => ({ error: "Bridge returned invalid JSON." }));
    return Response.json(data, { status: response.status, headers: cors });
  } catch (e) {
    return Response.json({ error: e instanceof Error ? e.message : "Bridge unavailable." }, { status: 502, headers: cors });
  }
});