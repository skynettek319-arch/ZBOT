import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405, headers: cors });

  const auth = req.headers.get("Authorization") || "";
  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
  const supabase = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: auth } } });
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) return Response.json({ error: "Unauthorized" }, { status: 401, headers: cors });

  const apiKey = Deno.env.get("XAI_API_KEY");
  if (!apiKey) return Response.json({ error: "XAI_API_KEY is not configured." }, { status: 503, headers: cors });

  try {
    const body = await req.json();
    const message = String(body.message || "").slice(0, 6000);
    const history = Array.isArray(body.history) ? body.history.slice(-12) : [];
    if (!message.trim()) return Response.json({ error: "Message is required." }, { status: 400, headers: cors });

    const messages = [
      { role: "system", content: "You are ZChatbot, the educational assistant inside ZBOTS. Explain trading concepts, MT5 setup, strategy configuration and risk management clearly. Do not promise profits, invent live account information, provide guaranteed signals, or claim to execute trades. You cannot place or modify trades. If asked about account-specific data, explain that you can only use data explicitly supplied in the conversation." },
      ...history.filter((m: any) => ["user", "assistant"].includes(m.role)).map((m: any) => ({ role: m.role, content: String(m.content).slice(0, 4000) })),
      { role: "user", content: message },
    ];
    const response = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: Deno.env.get("XAI_MODEL") || "grok-3-mini", messages, temperature: 0.3 }),
    });
    const result = await response.json();
    if (!response.ok) return Response.json({ error: result?.error?.message || "Grok API request failed." }, { status: 502, headers: cors });
    const reply = result?.choices?.[0]?.message?.content || "I couldn't generate a response.";
    return Response.json({ reply }, { headers: { ...cors, "Content-Type": "application/json" } });
  } catch (e) {
    return Response.json({ error: e instanceof Error ? e.message : "Unexpected server error." }, { status: 500, headers: cors });
  }
});