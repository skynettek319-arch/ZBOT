import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
const corsHeaders = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' }
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405)
  try {
    const url = Deno.env.get('SUPABASE_URL')!, anon = Deno.env.get('SUPABASE_ANON_KEY')!, service = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const authHeader = req.headers.get('Authorization') || ''
    const caller = createClient(url, anon, { global: { headers: { Authorization: authHeader } } })
    const { data: { user }, error: authError } = await caller.auth.getUser()
    if (authError || !user) return json({ error: 'Authentication required' }, 401)
    const admin = createClient(url, service, { auth: { autoRefreshToken: false, persistSession: false } })
    const { data: profile } = await admin.from('profiles').select('role,account_status').eq('id', user.id).maybeSingle()
    if (profile?.role !== 'admin' || profile.account_status !== 'active') return json({ error: 'Administrator access required' }, 403)
    const body = await req.json(), action = body.action
    if (action === 'overview') {
      const [users, strategies, subscriptions, audit, userList, mt5Accounts] = await Promise.all([
        admin.from('profiles').select('id', { count: 'exact', head: true }),
        admin.from('strategy_modules').select('id', { count: 'exact', head: true }),
        admin.from('subscriptions').select('id', { count: 'exact', head: true }),
        admin.from('admin_audit').select('id', { count: 'exact', head: true }),
        admin.auth.admin.listUsers({ page: 1, perPage: 100 }),
        admin.from('mt5_accounts').select('id', { count: 'exact', head: true })
      ])
      const [profiles, plans, activity, adminActivity] = await Promise.all([admin.from('profiles').select('id,full_name,role,account_status,created_at').order('created_at', { ascending: false }).limit(100), admin.from('plans').select('*').order('price_monthly'), admin.from('audit_logs').select('id,user_id,action,details,created_at').order('created_at',{ascending:false}).limit(30), admin.from('admin_audit').select('id,actor_id,target_user_id,action,details,created_at').order('created_at',{ascending:false}).limit(20)])
      const usersById = new Map((userList.data?.users || []).map((u) => [u.id, u]))
      const list = (profiles.data || []).map((p) => { const au = usersById.get(p.id); return { ...p, email: au?.email || '', banned_until: au?.banned_until || null, status: p.account_status } })
      await admin.from('admin_audit').insert({ actor_id: user.id, action: 'admin.overview.viewed', details: {} })
      return json({ overview: { users: users.count || 0, strategies: strategies.count || 0, subscriptions: subscriptions.count || 0, mt5_accounts: mt5Accounts.count || 0, audit_events: (audit.count || 0) + 1 }, users: list, plans: plans.data || [], activity: activity.data || [], admin_activity: adminActivity.data || [] })
    }
    if (action === 'ban' || action === 'unban') {
      const target = String(body.user_id || '')
      if (!target || target === user.id) return json({ error: 'A different target user is required' }, 400)
      const { data: targetProfile } = await admin.from('profiles').select('role').eq('id', target).maybeSingle()
      if (targetProfile?.role === 'admin') return json({ error: 'Admin accounts cannot be suspended from this screen' }, 403)
      const { error } = await admin.auth.admin.updateUserById(target, { ban_duration: action === 'ban' ? '876000h' : 'none' })
      if (error) return json({ error: error.message }, 400)
      await admin.from('profiles').update({ account_status: action === 'ban' ? 'suspended' : 'active' }).eq('id', target)
      await admin.from('admin_audit').insert({ actor_id: user.id, target_user_id: target, action: `user.${action}`, details: {} })
      return json({ success: true })
    }
    return json({ error: 'Unsupported admin action' }, 400)
  } catch (e) { return json({ error: e instanceof Error ? e.message : 'Unexpected server error' }, 500) }
})
