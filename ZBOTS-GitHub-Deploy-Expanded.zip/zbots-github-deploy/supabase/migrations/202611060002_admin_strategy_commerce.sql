-- ZBOTS expansion: modular strategy registry, admin controls, pricing, subscriptions and audit.
-- Apply after 202611060001_initial_schema.sql.

alter table public.profiles add column if not exists role text not null default 'trader' check (role in ('trader','admin','support'));
alter table public.profiles add column if not exists account_status text not null default 'active' check (account_status in ('active','suspended','closed'));
alter table public.profiles add column if not exists country text;
alter table public.profiles add column if not exists phone text;

create or replace function public.is_zbots_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin' and account_status='active'); $$;

create table if not exists public.strategy_modules (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 name text not null, description text not null default '', format text not null,
 manifest jsonb not null default '{}'::jsonb, version integer not null default 1,
 status text not null default 'draft' check(status in ('draft','validating','validated','backtesting','demo_testing','approved','active','paused','rejected','archived')),
 adapter_key text, validation_report jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.strategy_versions (
 id uuid primary key default gen_random_uuid(), strategy_module_id uuid not null references public.strategy_modules(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade, version integer not null,
 manifest jsonb not null, change_note text not null default '', created_at timestamptz not null default now(), unique(strategy_module_id,version)
);
create table if not exists public.strategy_runs (
 id uuid primary key default gen_random_uuid(), strategy_module_id uuid not null references public.strategy_modules(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade, run_type text not null check(run_type in ('validation','backtest','forward_demo','live')),
 status text not null default 'queued', parameters jsonb not null default '{}'::jsonb, results jsonb not null default '{}'::jsonb,
 started_at timestamptz, completed_at timestamptz, created_at timestamptz not null default now()
);
create table if not exists public.plans (
 id uuid primary key default gen_random_uuid(), code text unique not null, name text not null,
 description text not null default '', price_monthly numeric(12,2) not null default 0 check(price_monthly>=0),
 currency text not null default 'USD', features jsonb not null default '[]'::jsonb,
 limits jsonb not null default '{}'::jsonb, active boolean not null default true,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.subscriptions (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 plan_id uuid references public.plans(id), status text not null default 'pending' check(status in ('pending','trialing','active','past_due','cancelled','expired')),
 provider text, provider_reference text, current_period_start timestamptz, current_period_end timestamptz,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.platform_settings (
 key text primary key, value jsonb not null default '{}'::jsonb,
 updated_by uuid references auth.users(id) on delete set null, updated_at timestamptz not null default now()
);
create table if not exists public.admin_audit (
 id uuid primary key default gen_random_uuid(), actor_id uuid references auth.users(id) on delete set null,
 action text not null, target_user_id uuid references auth.users(id) on delete set null,
 details jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);

create index if not exists strategy_modules_owner_idx on public.strategy_modules(user_id,created_at desc);
create index if not exists strategy_runs_owner_idx on public.strategy_runs(user_id,created_at desc);
create index if not exists subscriptions_owner_idx on public.subscriptions(user_id,status);
create index if not exists admin_audit_created_idx on public.admin_audit(created_at desc);

alter table public.strategy_modules enable row level security;
alter table public.strategy_versions enable row level security;
alter table public.strategy_runs enable row level security;
alter table public.plans enable row level security;
alter table public.subscriptions enable row level security;
alter table public.platform_settings enable row level security;
alter table public.admin_audit enable row level security;

-- Replace profile update policy: users may update their profile fields but must not self-assign roles/status.
drop policy if exists "profile owner update" on public.profiles;
create or replace function public.protect_profile_privileges() returns trigger language plpgsql security definer set search_path=public as $$ begin if auth.uid() is not null and auth.uid()=old.id and not public.is_zbots_admin() then new.role:=old.role; new.account_status:=old.account_status; end if; return new; end; $$;
drop trigger if exists protect_profile_privileges_trigger on public.profiles;
create trigger protect_profile_privileges_trigger before update on public.profiles for each row execute function public.protect_profile_privileges();
create policy "profile owner update safe" on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
create policy "admin profile read" on public.profiles for select to authenticated using(public.is_zbots_admin());
create policy "admin profile update" on public.profiles for update to authenticated using(public.is_zbots_admin()) with check(public.is_zbots_admin());

create policy "strategy module owner all" on public.strategy_modules for all to authenticated using(user_id=auth.uid() or public.is_zbots_admin()) with check(user_id=auth.uid() or public.is_zbots_admin());
create policy "strategy versions owner read" on public.strategy_versions for select to authenticated using(user_id=auth.uid() or public.is_zbots_admin());
create policy "strategy versions owner insert" on public.strategy_versions for insert to authenticated with check(user_id=auth.uid() or public.is_zbots_admin());
create policy "strategy runs owner read" on public.strategy_runs for select to authenticated using(user_id=auth.uid() or public.is_zbots_admin());
create policy "strategy runs owner insert" on public.strategy_runs for insert to authenticated with check(user_id=auth.uid() or public.is_zbots_admin());
create policy "plans public active read" on public.plans for select to authenticated using(active=true or public.is_zbots_admin());
create policy "plans admin manage" on public.plans for all to authenticated using(public.is_zbots_admin()) with check(public.is_zbots_admin());
create policy "subscription owner read" on public.subscriptions for select to authenticated using(user_id=auth.uid() or public.is_zbots_admin());
create policy "platform settings admin read" on public.platform_settings for select to authenticated using(public.is_zbots_admin());
create policy "platform settings admin manage" on public.platform_settings for all to authenticated using(public.is_zbots_admin()) with check(public.is_zbots_admin());
create policy "admin audit admin read" on public.admin_audit for select to authenticated using(public.is_zbots_admin());

insert into public.plans(code,name,description,price_monthly,currency,features,limits) values
('starter','Starter','Essential automated trading workspace',19.99,'USD','["1 MT5 account","Basic strategy access","Core dashboard"]','{"mt5_accounts":1,"strategies":2}'),
('pro','Pro','Advanced strategy and risk workspace',39.99,'USD','["1 MT5 account","Advanced risk controls","Performance analytics"]','{"mt5_accounts":1,"strategies":10}'),
('premium','Premium','Expanded strategy and analytics access',79.99,'USD','["Multiple strategy modules","Advanced analytics","Priority support"]','{"mt5_accounts":5,"strategies":50}')
on conflict(code) do nothing;

-- Admin bootstrap: run once in Supabase SQL Editor after creating your own account.
-- Replace the email with the exact email you registered with, then remove/secure this SQL.
-- update public.profiles p set role='admin' from auth.users u where p.id=u.id and u.email='YOUR_ADMIN_EMAIL';
