-- ZBOTS initial schema. Run in Supabase SQL editor or apply with Supabase CLI.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.mt5_accounts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  broker text not null,
  login text not null,
  server text not null,
  account_type text not null check (account_type in ('Demo','Live')),
  connection_status text not null default 'disconnected',
  last_synced_at timestamptz,
  created_at timestamptz not null default now(),
  unique(user_id, login, server)
);
create table if not exists public.strategies (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  description text not null default '',
  enabled boolean not null default false,
  created_at timestamptz not null default now()
);
create table if not exists public.strategy_configurations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  mt5_account_id uuid references public.mt5_accounts(id) on delete cascade,
  strategy_id uuid references public.strategies(id),
  risk_percent numeric(6,3) not null default 1 check (risk_percent > 0 and risk_percent <= 5),
  max_daily_loss_percent numeric(6,3) not null default 2 check (max_daily_loss_percent > 0 and max_daily_loss_percent <= 20),
  max_positions integer not null default 5 check (max_positions between 1 and 30),
  settings jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  body text not null default '',
  category text not null default 'platform',
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create table if not exists public.chatbot_conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'New conversation',
  created_at timestamptz not null default now()
);
create table if not exists public.chatbot_messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.chatbot_conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('user','assistant')),
  content text not null,
  created_at timestamptz not null default now()
);
create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  action text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists mt5_accounts_user_idx on public.mt5_accounts(user_id);
create index if not exists strategy_config_user_idx on public.strategy_configurations(user_id);
create index if not exists notifications_user_created_idx on public.notifications(user_id, created_at desc);
create index if not exists chatbot_messages_conversation_idx on public.chatbot_messages(conversation_id, created_at);

alter table public.profiles enable row level security;
alter table public.mt5_accounts enable row level security;
alter table public.strategies enable row level security;
alter table public.strategy_configurations enable row level security;
alter table public.notifications enable row level security;
alter table public.chatbot_conversations enable row level security;
alter table public.chatbot_messages enable row level security;
alter table public.audit_logs enable row level security;

create policy "profile owner read" on public.profiles for select to authenticated using (id = auth.uid());
create policy "profile owner insert" on public.profiles for insert to authenticated with check (id = auth.uid());
create policy "profile owner update" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create policy "account owner read" on public.mt5_accounts for select to authenticated using (user_id = auth.uid());
create policy "account owner insert" on public.mt5_accounts for insert to authenticated with check (user_id = auth.uid());
create policy "account owner update" on public.mt5_accounts for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "strategies readable" on public.strategies for select to authenticated using (enabled = true);
create policy "strategy config owner all" on public.strategy_configurations for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "notifications owner all" on public.notifications for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "conversation owner all" on public.chatbot_conversations for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "messages owner all" on public.chatbot_messages for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "audit owner read" on public.audit_logs for select to authenticated using (user_id = auth.uid());

insert into public.strategies(slug,name,description,enabled) values
('nexus-supply-support','NEXUS Supply & Support','Supply and demand zones with multi-timeframe confirmation.',true),
('trend-force','Trend Force','Trend-following approach using directional filters.',true),
('smart-breakout','Smart Breakout','Breakout rules with volatility confirmation.',true),
('moving-average-trend','Moving Average Trend','Moving-average alignment and momentum conditions.',true),
('rsi-reversal','RSI Reversal','Mean-reversion setup using RSI conditions.',true),
('price-action','Price Action','Structured price-action entry and exit rules.',true)
on conflict (slug) do nothing;

-- Create/update a profile when an auth user is created.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''))
  on conflict (id) do update set full_name = excluded.full_name;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();
